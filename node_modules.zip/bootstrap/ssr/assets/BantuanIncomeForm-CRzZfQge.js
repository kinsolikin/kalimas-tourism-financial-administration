import { jsx, jsxs } from "react/jsx-runtime";
import { useState, useEffect } from "react";
import { A as Authenticated } from "./AuthenticatedLayout-b7V4Q5Tg.js";
import { useForm } from "@inertiajs/react";
import Swal from "sweetalert2";
import dayjs from "dayjs";
import "@headlessui/react";
const BantuanIncomeForm = ({ auth, incomes }) => {
  const [showHistory, setShowHistory] = useState(false);
  const [transactions, setTransactions] = useState([]);
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const { data, setData, post, processing, errors, reset } = useForm({
    sumber_bantuan: "",
    keterangan: "",
    total: 0
  });
  const handleSubmit = (e) => {
    e.preventDefault();
    post("/dashboard/bantuan-income/store", {
      onSuccess: () => {
        Swal.fire("Berhasil", "Data bantuan berhasil disimpan", "success");
        reset();
        if (showHistory) fetchTransactions();
      },
      onError: () => {
        Swal.fire("Gagal", "Gagal menyimpan data bantuan", "error");
      }
    });
  };
  const fetchTransactions = async (from = fromDate, to = toDate) => {
    try {
      let url = "/dashboard/bantuan/transactions";
      let params = {};
      if (from || to) {
        url = "/dashboard/bantuan/transactions/filter";
        params = { params: { from, to } };
      }
      const res = await axios.get(url, params);
      setTransactions(res.data);
    } catch (err) {
      console.error("Gagal mengambil data transaksi", err);
    }
  };
  useEffect(() => {
    if (showHistory) {
      fetchTransactions();
    }
  }, [fromDate, toDate, showHistory]);
  const deleteAllTransactions = async () => {
    const result = await Swal.fire({
      title: "Hapus semua transaksi?",
      text: "Tindakan ini tidak bisa dibatalkan!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Ya, hapus!",
      cancelButtonText: "Batal"
    });
    if (result.isConfirmed) {
      try {
        await axios.delete("/dashboard/bantuan/transactions/delete-all");
        setTransactions([]);
        Swal.fire("Berhasil!", "Semua transaksi telah dihapus.", "success");
        if (showHistory) fetchTransactions();
      } catch (err) {
        console.error("Gagal hapus transaksi", err);
      }
    }
  };
  const deleteTransaction = async (id) => {
    const result = await Swal.fire({
      title: "Hapus transaksi ini?",
      text: "Tindakan ini tidak bisa dibatalkan!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Ya, hapus!",
      cancelButtonText: "Batal"
    });
    if (result.isConfirmed) {
      try {
        await axios.delete(`/dashboard/bantuan/transactions/delete/${id}`);
        setTransactions((prev) => prev.filter((t) => t.id !== id));
        Swal.fire("Berhasil!", "Transaksi telah dihapus.", "success");
        if (showHistory) fetchTransactions();
      } catch (err) {
        Swal.fire("Gagal!", "Gagal menghapus transaksi.", "error");
      }
    }
  };
  return /* @__PURE__ */ jsx(Authenticated, { user: auth.user, children: /* @__PURE__ */ jsx("div", { className: "max-w-lg mx-auto py-8 px-4", children: /* @__PURE__ */ jsxs("div", { className: "bg-white  shadow-lg p-8", children: [
    /* @__PURE__ */ jsx("h1", { className: "text-2xl font-bold text-blue-700 mb-6 text-center", children: "Input Bantuan Pemasukan" }),
    /* @__PURE__ */ jsxs("form", { onSubmit: handleSubmit, className: "space-y-5", children: [
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("label", { className: "block mb-1 text-sm font-semibold text-gray-700", children: "Sumber Bantuan" }),
        /* @__PURE__ */ jsx(
          "input",
          {
            type: "text",
            value: data.sumber_bantuan,
            onChange: (e) => setData("sumber_bantuan", e.target.value),
            className: "w-full border border-gray-300 px-4 py-2  focus:ring-2 focus:ring-blue-200 focus:outline-none",
            required: true,
            placeholder: "Masukkan nama pemberi bantuan"
          }
        ),
        errors.sumber_bantuan && /* @__PURE__ */ jsx("p", { className: "text-red-500 text-xs mt-1", children: errors.sumber_bantuan })
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("label", { className: "block mb-1 text-sm font-semibold text-gray-700", children: "Keterangan" }),
        /* @__PURE__ */ jsx(
          "textarea",
          {
            value: data.keterangan,
            onChange: (e) => setData("keterangan", e.target.value),
            className: "w-full border border-gray-300 px-4 py-2  focus:ring-2 focus:ring-blue-200 focus:outline-none",
            rows: 3,
            placeholder: "Keterangan tambahan (opsional)"
          }
        ),
        errors.keterangan && /* @__PURE__ */ jsx("p", { className: "text-red-500 text-xs mt-1", children: errors.keterangan })
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("label", { className: "block mb-1 text-sm font-semibold text-gray-700", children: "Total Bantuan (Rp)" }),
        /* @__PURE__ */ jsx(
          "input",
          {
            type: "number",
            min: "0",
            step: "0.01",
            value: data.total,
            onChange: (e) => setData("total", e.target.value),
            className: "w-full border border-gray-300 px-4 py-2  focus:ring-2 focus:ring-blue-200 focus:outline-none",
            required: true,
            placeholder: "Masukkan nominal bantuan"
          }
        ),
        errors.total && /* @__PURE__ */ jsx("p", { className: "text-red-500 text-xs mt-1", children: errors.total })
      ] }),
      /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx(
        "button",
        {
          type: "submit",
          disabled: processing,
          className: "w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-2  transition",
          children: processing ? "Menyimpan..." : "Simpan Bantuan"
        }
      ) })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "mt-6", children: /* @__PURE__ */ jsx(
      "button",
      {
        onClick: () => setShowHistory(true),
        className: "w-full bg-green-600 hover:bg-green-700 text-white font-semibold py-3 ",
        children: "📋 Lihat Riwayat Transaksi"
      }
    ) }),
    showHistory && /* @__PURE__ */ jsxs("div", { className: "mt-8 bg-white rounded-lg p-6 w-full shadow-lg border mx-auto", children: [
      /* @__PURE__ */ jsx("h2", { className: "text-xl font-bold mb-4", children: "Riwayat Transaksi Bantuan" }),
      /* @__PURE__ */ jsxs("div", { className: "flex gap-4 mb-4", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("label", { className: "block text-sm", children: "Dari" }),
          /* @__PURE__ */ jsx(
            "input",
            {
              type: "date",
              value: fromDate,
              onChange: (e) => setFromDate(e.target.value),
              className: "border p-2 "
            }
          )
        ] }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("label", { className: "block text-sm", children: "Sampai" }),
          /* @__PURE__ */ jsx(
            "input",
            {
              type: "date",
              value: toDate,
              onChange: (e) => setToDate(e.target.value),
              className: "border p-2 "
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxs("table", { className: "w-full text-left border", children: [
        /* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", { className: "bg-gray-100", children: [
          /* @__PURE__ */ jsx("th", { className: "p-2 border", children: "Tanggal" }),
          /* @__PURE__ */ jsx("th", { className: "p-2 border", children: "Jumlah" }),
          /* @__PURE__ */ jsx("th", { className: "p-2 border", children: "Total" }),
          /* @__PURE__ */ jsx("th", { className: "p-2 border", children: "Aksi" })
        ] }) }),
        /* @__PURE__ */ jsx("tbody", { children: transactions.length === 0 ? /* @__PURE__ */ jsx("tr", { children: /* @__PURE__ */ jsx("td", { colSpan: "4", className: "p-4 text-center", children: "Belum ada transaksi" }) }) : transactions.map((trx) => /* @__PURE__ */ jsxs("tr", { children: [
          /* @__PURE__ */ jsx("td", { className: "p-2 border", children: dayjs(trx.created_at).format("DD/MM/YYYY") }),
          /* @__PURE__ */ jsx("td", { className: "p-2 border", children: trx.jumlah_pengguna }),
          /* @__PURE__ */ jsxs("td", { className: "p-2 border", children: [
            "Rp ",
            trx.total.toLocaleString()
          ] }),
          /* @__PURE__ */ jsx("td", { className: "p-2 border", children: /* @__PURE__ */ jsx(
            "button",
            {
              onClick: () => deleteTransaction(trx.id),
              className: "text-red-600 hover:underline",
              children: "Hapus"
            }
          ) })
        ] }, trx.id)) })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex justify-between mt-4", children: [
        transactions.length > 0 && /* @__PURE__ */ jsx(
          "button",
          {
            onClick: deleteAllTransactions,
            className: "text-red-600 hover:underline",
            children: "🗑 Hapus Semua"
          }
        ),
        /* @__PURE__ */ jsx(
          "button",
          {
            onClick: () => setShowHistory(false),
            className: "text-gray-600 hover:underline",
            children: "❌ Tutup"
          }
        )
      ] })
    ] })
  ] }) }) });
};
export {
  BantuanIncomeForm as default
};

import { jsxs, jsx } from "react/jsx-runtime";
import { A as Authenticated } from "./AuthenticatedLayout-b7V4Q5Tg.js";
import { usePage, useForm, Head } from "@inertiajs/react";
import { useEffect } from "react";
import Swal from "sweetalert2";
import "@headlessui/react";
function Dashboard({ auth, transactions }) {
  const { props } = usePage();
  const { status, message } = props;
  const { data, setData, post, processing, errors } = useForm({
    shift: "1",
    operator_name: "",
    vehicle_type: "",
    price: 0,
    jumlah_tiket: 0,
    harga_tiket: 0,
    jam_masuk: (/* @__PURE__ */ new Date()).toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" }),
    // Default to current time
    jam_keluar: "16:00"
  });
  useEffect(() => {
    const now = /* @__PURE__ */ new Date();
    const hours = String(now.getHours()).padStart(2, "0");
    const minutes = String(now.getMinutes()).padStart(2, "0");
    setData("jam_masuk", `${hours}:${minutes}`);
  }, []);
  useEffect(() => {
    console.log("Status:", status);
    console.log("Message:", message);
    if (status && message) {
      Swal.fire({
        icon: status === "success" ? "success" : "error",
        title: status === "success" ? "Berhasil" : "Gagal",
        text: message
      });
    }
  }, [status, message]);
  return /* @__PURE__ */ jsxs(
    Authenticated,
    {
      user: auth.user,
      header: /* @__PURE__ */ jsx("h2", { className: "font-semibold text-xl text-gray-800 leading-tight", children: "Riwayat Transaksi" }),
      children: [
        /* @__PURE__ */ jsx(Head, { title: "Riwayat Transaksi" }),
        /* @__PURE__ */ jsx("div", { className: "py-12", children: /* @__PURE__ */ jsx("div", { className: "max-w-7xl mx-auto sm:px-6 lg:px-8", children: /* @__PURE__ */ jsx("div", { className: "bg-white overflow-hidden shadow-sm sm:rounded-lg", children: /* @__PURE__ */ jsx("div", { className: "p-6 bg-white border-b border-gray-200", children: /* @__PURE__ */ jsxs("table", { className: "table-auto w-full border-collapse border border-gray-300", children: [
          /* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", { children: [
            /* @__PURE__ */ jsx("th", { className: "border border-gray-300 px-4 py-2", children: "No" }),
            /* @__PURE__ */ jsx("th", { className: "border border-gray-300 px-4 py-2", children: "Operator" }),
            /* @__PURE__ */ jsx("th", { className: "border border-gray-300 px-4 py-2", children: "Jenis Kendaraan" }),
            /* @__PURE__ */ jsx("th", { className: "border border-gray-300 px-4 py-2", children: "Harga" }),
            /* @__PURE__ */ jsx("th", { className: "border border-gray-300 px-4 py-2", children: "Jumlah Tiket" }),
            /* @__PURE__ */ jsx("th", { className: "border border-gray-300 px-4 py-2", children: "Jam Masuk" }),
            /* @__PURE__ */ jsx("th", { className: "border border-gray-300 px-4 py-2", children: "Jam Keluar" })
          ] }) }),
          /* @__PURE__ */ jsx("tbody", { children: transactions.map((transaction, index) => /* @__PURE__ */ jsxs("tr", { children: [
            /* @__PURE__ */ jsx("td", { className: "border border-gray-300 px-4 py-2", children: index + 1 }),
            /* @__PURE__ */ jsx("td", { className: "border border-gray-300 px-4 py-2", children: transaction.operator_name }),
            /* @__PURE__ */ jsx("td", { className: "border border-gray-300 px-4 py-2", children: transaction.vehicle_type }),
            /* @__PURE__ */ jsx("td", { className: "border border-gray-300 px-4 py-2", children: transaction.price }),
            /* @__PURE__ */ jsx("td", { className: "border border-gray-300 px-4 py-2", children: transaction.jumlah_tiket }),
            /* @__PURE__ */ jsx("td", { className: "border border-gray-300 px-4 py-2", children: transaction.jam_masuk }),
            /* @__PURE__ */ jsx("td", { className: "border border-gray-300 px-4 py-2", children: transaction.jam_keluar })
          ] }, transaction.id)) })
        ] }) }) }) }) })
      ]
    }
  );
}
export {
  Dashboard as default
};

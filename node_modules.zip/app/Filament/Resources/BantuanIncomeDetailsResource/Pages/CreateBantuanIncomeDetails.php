<?php

namespace App\Filament\Resources\BantuanIncomeDetailsResource\Pages;

use App\Filament\Resources\BantuanIncomeDetailsResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateBantuanIncomeDetails extends CreateRecord
{
    protected static string $resource = BantuanIncomeDetailsResource::class;
}

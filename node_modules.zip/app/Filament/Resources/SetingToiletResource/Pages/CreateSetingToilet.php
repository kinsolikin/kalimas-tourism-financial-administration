<?php

namespace App\Filament\Resources\SetingToiletResource\Pages;

use App\Filament\Resources\SetingToiletResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateSetingToilet extends CreateRecord
{
    protected static string $resource = SetingToiletResource::class;
}

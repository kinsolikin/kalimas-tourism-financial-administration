<?php

namespace App\Filament\Resources\ListShiftResource\Pages;

use App\Filament\Resources\ListShiftResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateListShift extends CreateRecord
{
    protected static string $resource = ListShiftResource::class;
}

<?php

namespace App\Filament\Resources\WahanaResource\Pages;

use App\Filament\Resources\WahanaResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateWahana extends CreateRecord
{
    protected static string $resource = WahanaResource::class;
}

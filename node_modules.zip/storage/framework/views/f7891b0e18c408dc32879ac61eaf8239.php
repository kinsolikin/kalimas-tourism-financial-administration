<p
    class="fi-section-header-description text-sm text-gray-500 dark:text-gray-400"
>
    <?php echo e($slot); ?>

</p>
<?php /**PATH D:\skripsi gatel\proyek\administrasikalimas\resources\views/vendor/filament/components/section/description.blade.php ENDPATH**/ ?>
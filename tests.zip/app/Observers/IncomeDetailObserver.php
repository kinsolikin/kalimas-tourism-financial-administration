<?php

namespace App\Observers;

class IncomeDetailObserver
{
    public function deleted($detail)
    {

       
    }
    
}

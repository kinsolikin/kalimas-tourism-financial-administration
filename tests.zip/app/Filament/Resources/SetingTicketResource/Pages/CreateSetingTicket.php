<?php

namespace App\Filament\Resources\SetingTicketResource\Pages;

use App\Filament\Resources\SetingTicketResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateSetingTicket extends CreateRecord
{
    protected static string $resource = SetingTicketResource::class;
}

import { jsx, jsxs } from "react/jsx-runtime";
import { useState, useEffect } from "react";
import { usePage, useForm, router } from "@inertiajs/react";
import { A as Authenticated } from "./AuthenticatedLayout-b7V4Q5Tg.js";
import Swal from "sweetalert2";
import dayjs from "dayjs";
import axios from "axios";
import "@headlessui/react";
const Toilet = ({ auth }) => {
  const [showModal, setShowModal] = useState(false);
  const [transactions, setTransactions] = useState([]);
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [showEndShiftModal, setShowEndShiftModal] = useState(false);
  const [todayTransactions, setTodayTransactions] = useState([]);
  const { priceToilet } = usePage().props;
  console.log("Price Toilet:", priceToilet);
  const fixedHarga = parseInt((priceToilet == null ? void 0 : priceToilet.price) ?? 0);
  const { data, setData, post, processing, errors } = useForm({
    jumlah: 0,
    harga_perorang: fixedHarga,
    total: 0
  });
  useEffect(() => {
    setData((prev) => ({
      ...prev,
      total: fixedHarga * prev.jumlah
    }));
  }, [data.jumlah]);
  const handleSubmit = (e) => {
    e.preventDefault();
    post("/dashboard/toilet/store", {
      onSuccess: () => {
        setData({
          jumlah: 0,
          harga_perorang: fixedHarga,
          total: 0
        });
        openModal();
        setShowModal(true);
        Swal.fire(
          "Berhasil",
          "Data Toilet berhasil disimpan",
          "success"
        );
      },
      onError: () => {
        Swal.fire("Gagal", "Data Toilet gagal disimpan", "error");
      }
    });
  };
  const openModal = async () => {
    try {
      const res = await axios.get("/dashboard/toilet/transactions");
      setTransactions(res.data);
      setShowModal(true);
    } catch (err) {
      console.error("Gagal mengambil data transaksi", err);
    }
  };
  const fetchTransactions = async () => {
    try {
      const res = await axios.get(
        "/dashboard/toilet/transactions/filter",
        {
          params: { from: fromDate, to: toDate }
        }
      );
      setTransactions(res.data);
    } catch (err) {
      console.error("Gagal filter data", err);
    }
  };
  const deleteAllTransactions = async () => {
    const result = await Swal.fire({
      title: "Hapus semua transaksi?",
      text: "Tindakan ini tidak bisa dibatalkan!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Ya, hapus!",
      cancelButtonText: "Batal"
    });
    if (result.isConfirmed) {
      try {
        await axios.delete("/dashboard/toilet/transactions/delete-all");
        setTransactions([]);
        Swal.fire(
          "Berhasil!",
          "Semua transaksi telah dihapus.",
          "success"
        );
      } catch (err) {
        console.error("Gagal hapus transaksi", err);
      }
    }
  };
  const deleteTransaction = async (id) => {
    const result = await Swal.fire({
      title: "Hapus transaksi ini?",
      text: "Tindakan ini tidak bisa dibatalkan!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Ya, hapus!",
      cancelButtonText: "Batal"
    });
    if (result.isConfirmed) {
      try {
        await axios.delete(
          `/dashboard/toilet/transactions/delete/${id}`
        );
        setTransactions((prev) => prev.filter((t) => t.id !== id));
        Swal.fire("Berhasil!", "Transaksi telah dihapus.", "success");
      } catch (err) {
        Swal.fire("Gagal!", "Gagal menghapus transaksi.", "error");
      }
    }
  };
  const endShift = async () => {
    try {
      const res = await axios.get("/dashboard/toilet/transactions");
      setTodayTransactions(res.data);
      setShowEndShiftModal(true);
    } catch (err) {
      Swal.fire(
        "Gagal!",
        "Gagal mengambil data transaksi hari ini.",
        "error"
      );
    }
  };
  const confirmEndShift = async () => {
    const result = await Swal.fire({
      title: "Akhiri Shift?",
      text: "Pastikan semua transaksi sudah dicatat. Anda yakin ingin mengakhiri shift?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Ya, akhiri!",
      cancelButtonText: "Batal"
    });
    if (result.isConfirmed) {
      try {
        await router.post("/logout");
        Swal.fire("Berhasil!", "Shift telah diakhiri.", "success").then(
          () => {
            window.location.reload();
          }
        );
      } catch (err) {
        Swal.fire("Gagal!", "Gagal mengakhiri shift.", "error");
      }
    }
  };
  return /* @__PURE__ */ jsx(Authenticated, { user: auth.user, children: /* @__PURE__ */ jsxs("div", { className: "max-w-3xl mx-auto px-4 py-6", children: [
    /* @__PURE__ */ jsx("h1", { className: "text-2xl font-bold text-center mb-4", children: "Form Pemasukan Toilet" }),
    /* @__PURE__ */ jsx("div", { className: "bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4 mb-4  ", children: priceToilet && priceToilet.price ? /* @__PURE__ */ jsxs("p", { children: [
      /* @__PURE__ */ jsx("strong", { children: "Informasi:" }),
      " Setiap 1 orang pengguna toilet dikenakan biaya",
      " ",
      /* @__PURE__ */ jsxs("strong", { children: [
        "Rp",
        " ",
        Number(priceToilet.price).toLocaleString(
          "id-ID"
        )
      ] }),
      "."
    ] }) : /* @__PURE__ */ jsx("p", { className: "text-red-600", children: /* @__PURE__ */ jsx("strong", { children: "Maaf, silakan hubungi Admin/Ketua Wisata karena harga toilet belum ditetapkan." }) }) }),
    /* @__PURE__ */ jsxs(
      "form",
      {
        onSubmit: handleSubmit,
        className: "bg-white p-6   shadow-md space-y-6",
        children: [
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx(
              "label",
              {
                htmlFor: "jumlah",
                className: "block mb-1 font-medium",
                children: "Jumlah Pengguna Toilet"
              }
            ),
            /* @__PURE__ */ jsx(
              "input",
              {
                disabled: !priceToilet || !priceToilet.price,
                type: "number",
                id: "jumlah",
                min: "1",
                value: data.jumlah,
                onChange: (e) => setData("jumlah", parseInt(e.target.value)),
                className: "w-full border px-4 py-2  ",
                required: true
              }
            ),
            errors.jumlah && /* @__PURE__ */ jsx("p", { className: "text-red-500 text-sm", children: errors.jumlah })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "text-lg font-semibold", children: [
            "Total Bayar: Rp ",
            data.total.toLocaleString()
          ] }),
          /* @__PURE__ */ jsx(
            "button",
            {
              type: "submit",
              disabled: processing,
              className: "w-full bg-blue-600 hover:bg-blue-700 text-white py-2  ",
              children: processing ? "Menyimpan..." : "Simpan"
            }
          )
        ]
      }
    ),
    /* @__PURE__ */ jsx("div", { className: "mt-6", children: /* @__PURE__ */ jsx(
      "button",
      {
        onClick: openModal,
        className: "w-full bg-green-600 hover:bg-green-700 text-white font-semibold py-3  ",
        children: "📋 Lihat Riwayat Transaksi"
      }
    ) }),
    /* @__PURE__ */ jsx("div", { className: "mt-2", children: /* @__PURE__ */ jsx(
      "button",
      {
        onClick: endShift,
        className: "w-full bg-red-600 hover:bg-red-700 text-white font-semibold py-3  ",
        children: "⏹ Akhiri Shift"
      }
    ) }),
    showEndShiftModal && /* @__PURE__ */ jsxs("div", { className: "mt-8 bg-white   shadow-md p-6 border border-red-200", children: [
      /* @__PURE__ */ jsx("h2", { className: "text-xl font-bold mb-4 text-red-700", children: "Transaksi Hari Ini (Shift)" }),
      /* @__PURE__ */ jsxs("table", { className: "w-full text-left border mb-4", children: [
        /* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", { className: "bg-gray-100", children: [
          /* @__PURE__ */ jsx("th", { className: "p-2 border", children: "Tanggal" }),
          /* @__PURE__ */ jsx("th", { className: "p-2 border", children: "Jumlah" }),
          /* @__PURE__ */ jsx("th", { className: "p-2 border", children: "Total" })
        ] }) }),
        /* @__PURE__ */ jsx("tbody", { children: todayTransactions.length === 0 ? /* @__PURE__ */ jsx("tr", { children: /* @__PURE__ */ jsx(
          "td",
          {
            colSpan: "3",
            className: "p-4 text-center",
            children: "Tidak ada transaksi hari ini"
          }
        ) }) : todayTransactions.map((trx) => /* @__PURE__ */ jsxs("tr", { children: [
          /* @__PURE__ */ jsx("td", { className: "p-2 border", children: dayjs(trx.created_at).format(
            "DD/MM/YYYY"
          ) }),
          /* @__PURE__ */ jsx("td", { className: "p-2 border", children: trx.jumlah_pengguna }),
          /* @__PURE__ */ jsxs("td", { className: "p-2 border", children: [
            "Rp ",
            trx.total.toLocaleString()
          ] })
        ] }, trx.id)) })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex justify-between", children: [
        /* @__PURE__ */ jsx(
          "button",
          {
            onClick: confirmEndShift,
            className: "bg-red-600 hover:bg-red-700 text-white px-4 py-2  ",
            children: "⏹ Tutup & Akhiri Shift"
          }
        ),
        /* @__PURE__ */ jsx(
          "button",
          {
            onClick: () => setShowEndShiftModal(false),
            className: "bg-gray-300 hover:bg-gray-400 text-gray-800 px-4 py-2  ",
            children: "Batal"
          }
        )
      ] })
    ] }),
    showModal && /* @__PURE__ */ jsxs("div", { className: "mt-8 bg-white   shadow-md p-6 border border-green-200", children: [
      /* @__PURE__ */ jsx("h2", { className: "text-xl font-bold mb-4", children: "Riwayat Transaksi Toilet" }),
      /* @__PURE__ */ jsxs("div", { className: "flex gap-4 mb-4", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("label", { className: "block text-sm", children: "Dari" }),
          /* @__PURE__ */ jsx(
            "input",
            {
              type: "date",
              value: fromDate,
              onChange: (e) => setFromDate(e.target.value),
              className: "border p-2  "
            }
          )
        ] }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("label", { className: "block text-sm", children: "Sampai" }),
          /* @__PURE__ */ jsx(
            "input",
            {
              type: "date",
              value: toDate,
              onChange: (e) => setToDate(e.target.value),
              className: "border p-2  "
            }
          )
        ] }),
        /* @__PURE__ */ jsx("div", { className: "flex items-end", children: /* @__PURE__ */ jsx(
          "button",
          {
            onClick: fetchTransactions,
            className: "bg-blue-500 hover:bg-blue-600 text-white px-4 py-2  ",
            children: "Filter"
          }
        ) })
      ] }),
      /* @__PURE__ */ jsxs("table", { className: "w-full text-left border", children: [
        /* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", { className: "bg-gray-100", children: [
          /* @__PURE__ */ jsx("th", { className: "p-2 border", children: "Tanggal" }),
          /* @__PURE__ */ jsx("th", { className: "p-2 border", children: "Jumlah" }),
          /* @__PURE__ */ jsx("th", { className: "p-2 border", children: "Total" }),
          /* @__PURE__ */ jsx("th", { className: "p-2 border", children: "Aksi" })
        ] }) }),
        /* @__PURE__ */ jsx("tbody", { children: transactions.length === 0 ? /* @__PURE__ */ jsx("tr", { children: /* @__PURE__ */ jsx(
          "td",
          {
            colSpan: "4",
            className: "p-4 text-center",
            children: "Belum ada transaksi"
          }
        ) }) : transactions.map((trx) => /* @__PURE__ */ jsxs("tr", { children: [
          /* @__PURE__ */ jsx("td", { className: "p-2 border", children: dayjs(trx.created_at).format(
            "DD/MM/YYYY"
          ) }),
          /* @__PURE__ */ jsx("td", { className: "p-2 border", children: trx.jumlah_pengguna }),
          /* @__PURE__ */ jsxs("td", { className: "p-2 border", children: [
            "Rp ",
            trx.total.toLocaleString()
          ] }),
          /* @__PURE__ */ jsx("td", { className: "p-2 border", children: /* @__PURE__ */ jsx(
            "button",
            {
              onClick: () => deleteTransaction(
                trx.id
              ),
              className: "text-red-600 hover:underline",
              children: "Hapus"
            }
          ) })
        ] }, trx.id)) })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex justify-between mt-4", children: [
        /* @__PURE__ */ jsx(
          "button",
          {
            onClick: deleteAllTransactions,
            className: "text-red-600 hover:underline",
            children: "🗑 Hapus Semua"
          }
        ),
        /* @__PURE__ */ jsx(
          "button",
          {
            onClick: () => setShowModal(false),
            className: "text-gray-600 hover:underline",
            children: "❌ Tutup"
          }
        )
      ] })
    ] })
  ] }) });
};
export {
  Toilet as default
};

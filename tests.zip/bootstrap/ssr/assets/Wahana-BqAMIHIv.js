import { jsx, jsxs } from "react/jsx-runtime";
import { useState, useRef, useEffect } from "react";
import { usePage, useForm, router } from "@inertiajs/react";
import { A as Authenticated } from "./AuthenticatedLayout-b7V4Q5Tg.js";
import Swal from "sweetalert2";
import dayjs from "dayjs";
import axios from "axios";
import "@headlessui/react";
const Wahana = ({ auth }) => {
  const { wahanaoption } = usePage().props;
  console.log("Wahana Options:", wahanaoption);
  const [transactions, setTransactions] = useState([]);
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [showShiftSummary, setShowShiftSummary] = useState(false);
  const [closingShift, setClosingShift] = useState(false);
  const [todaySummary, setTodaySummary] = useState({
    wahana: [],
    totalWahana: 0
  });
  const shiftSummaryRef = useRef(null);
  const { data, setData, post, processing, errors, reset } = useForm({
    wahana_id: "",
    harga: 0,
    jumlah: 0,
    total: 0,
    nama_wahana: ""
  });
  const fetchTransactions = async () => {
    try {
      const res = await axios.get("/dashboard/wahana/transactions");
      setTransactions(res.data);
    } catch (error) {
      Swal.fire("Gagal", "Gagal mengambil data transaksi", "error");
    }
  };
  useEffect(() => {
    fetchTransactions();
  }, []);
  useEffect(() => {
    const selected = Object.values(wahanaoption || {}).find(
      (w) => String(w.id) === String(data.wahana_id)
    );
    const harga = selected ? Number(selected.price) : 0;
    const nama_wahana = selected ? selected.jeniswahana : "";
    setData((prev) => ({
      ...prev,
      harga,
      total: harga * (Number(prev.jumlah) || 0),
      nama_wahana
    }));
  }, [data.wahana_id, data.jumlah, wahanaoption]);
  const handleSubmit = (e) => {
    e.preventDefault();
    post("/dashboard/wahana/store", {
      onSuccess: () => {
        reset();
        Swal.fire(
          "Berhasil",
          "Data Wahana berhasil disimpan",
          "success"
        );
        fetchTransactions();
      },
      onError: () => {
        Swal.fire({
          title: "Gagal",
          text: "Data wahana gagal disimpan",
          icon: "error",
          confirmButtonColor: "#d33"
        });
      }
    });
  };
  const fetchFilteredTransactions = async () => {
    try {
      const res = await axios.get(
        "/dashboard/wahana/transactions/filter",
        {
          params: {
            from: fromDate,
            to: toDate
          }
        }
      );
      setTransactions(res.data);
    } catch (err) {
      Swal.fire("Gagal", "Gagal ambil data", "error");
    }
  };
  const deleteAllTransactions = async () => {
    const result = await Swal.fire({
      title: "Yakin ingin menghapus Semua transaksi ini?",
      text: "Tindakan ini tidak bisa dibatalkan!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#d33",
      cancelButtonColor: "#3085d6",
      confirmButtonText: "Ya, hapus!",
      cancelButtonText: "Batal"
    });
    if (result.isConfirmed) {
      Swal.fire({
        title: "Menghapus...",
        text: "Silakan tunggu...",
        allowOutsideClick: false,
        didOpen: () => {
          Swal.showLoading();
        }
      });
      try {
        await axios.delete("/dashboard/wahana/transactions/delete-all");
        setTransactions([]);
        Swal.fire("Berhasil!", "Transaksi telah dihapus.", "success");
      } catch (error) {
        Swal.fire("Gagal!", "Gagal menghapus transaksi.", "error");
      }
    }
  };
  const deleteTransaction = async (id) => {
    const result = await Swal.fire({
      title: "Yakin ingin menghapus transaksi ini?",
      text: "Tindakan ini tidak bisa dibatalkan!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#d33",
      cancelButtonColor: "#3085d6",
      confirmButtonText: "Ya, hapus!",
      cancelButtonText: "Batal"
    });
    if (result.isConfirmed) {
      try {
        await axios.delete(
          `/dashboard/wahana/transactions/delete/${id}`
        );
        setTransactions(
          (prev) => prev.filter((item) => item.id !== id)
        );
        Swal.fire("Berhasil!", "Transaksi telah dihapus.", "success");
      } catch (error) {
        Swal.fire("Gagal!", "Gagal menghapus transaksi.", "error");
      }
    }
  };
  const getTodayTransactions = () => {
    const today = /* @__PURE__ */ new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(today.getDate() + 1);
    const wahana = (transactions || []).filter((t) => {
      const d = new Date(t.created_at);
      return d >= today && d < tomorrow;
    });
    const totalWahana = wahana.reduce(
      (sum, t) => sum + Number(t.harga || 0) * Number(t.jumlah || 0),
      0
    );
    return {
      wahana,
      totalWahana
    };
  };
  const handleEndShift = () => {
    const summary = getTodayTransactions();
    setTodaySummary(summary);
    setShowShiftSummary(true);
  };
  const handleSaveShiftAndLogout = async () => {
    setClosingShift(true);
    try {
      const result = await Swal.fire({
        title: "Yakin ingin akhiri shift ?",
        text: "Tindakan ini tidak bisa dibatalkan!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#d33",
        cancelButtonColor: "#3085d6",
        confirmButtonText: "Ya, akhiri!",
        cancelButtonText: "Batal"
      });
      if (result.isConfirmed) {
        const rresult = await Swal.fire({
          title: "Menyimpan shift...",
          text: "Silakan tunggu...",
          allowOutsideClick: false,
          didOpen: () => {
            Swal.showLoading();
            setTimeout(() => {
              Swal.close();
              Swal.fire({
                icon: "success",
                title: "Berhasil!",
                text: "Shift berhasil disimpan.",
                timer: 2e3,
                showConfirmButton: false
              });
            }, 3e3);
          }
        });
        router.post("/logout");
      }
    } catch (error) {
      Swal.fire({
        icon: "error",
        title: "Gagal",
        text: "Gagal menyimpan shift atau logout."
      });
    } finally {
      setClosingShift(false);
    }
  };
  const handleShowShiftSummary = () => {
    setShowShiftSummary((prev) => {
      if (!prev) handleEndShift();
      setTimeout(() => {
        if (!prev && shiftSummaryRef.current) {
          shiftSummaryRef.current.scrollIntoView({
            behavior: "smooth"
          });
        }
      }, 100);
      if (prev) setShowShiftSummary(false);
      return !prev;
    });
  };
  return /* @__PURE__ */ jsx(Authenticated, { user: auth.user, children: /* @__PURE__ */ jsxs("div", { className: "max-w-5xl mx-auto px-4 py-6", children: [
    /* @__PURE__ */ jsx("h1", { className: "text-2xl font-bold mb-6 text-center", children: "Form Pemasukan Wahana" }),
    /* @__PURE__ */ jsxs("div", { className: "flex flex-col md:grid md:grid-cols-2 gap-6", children: [
      /* @__PURE__ */ jsxs(
        "form",
        {
          onSubmit: handleSubmit,
          className: "space-y-6 bg-white p-4 md:p-6   shadow-md border",
          children: [
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx(
                "label",
                {
                  htmlFor: "harga",
                  className: "block text-sm font-semibold mb-1",
                  children: "Harga Satuan (Rp)"
                }
              ),
              /* @__PURE__ */ jsx(
                "input",
                {
                  type: "text",
                  id: "harga",
                  value: (Number(data.harga) || 0).toLocaleString(),
                  disabled: true,
                  className: "w-full bg-gray-100 border border-gray-300   px-4 py-2 text-gray-600"
                }
              )
            ] }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx(
                "label",
                {
                  htmlFor: "jumlah",
                  className: "block text-sm font-semibold mb-1",
                  children: "Jumlah Tiket"
                }
              ),
              /* @__PURE__ */ jsx(
                "input",
                {
                  type: "number",
                  id: "jumlah",
                  min: "1",
                  value: data.jumlah,
                  onChange: (e) => {
                    const val = e.target.value;
                    setData(
                      "jumlah",
                      val === "" ? "" : parseInt(val)
                    );
                  },
                  className: "w-full border border-gray-300   px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500",
                  required: true
                }
              ),
              errors.jumlah && /* @__PURE__ */ jsx("p", { className: "text-red-500 text-sm mt-1", children: errors.jumlah })
            ] }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx(
                "label",
                {
                  htmlFor: "wahana_id",
                  className: "block text-sm font-semibold mb-1",
                  children: "Jenis Wahana"
                }
              ),
              /* @__PURE__ */ jsxs(
                "select",
                {
                  id: "wahana_id",
                  value: data.wahana_id,
                  onChange: (e) => setData({
                    ...data,
                    wahana_id: e.target.value
                  }),
                  className: "w-full border border-gray-300   px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500",
                  required: true,
                  children: [
                    /* @__PURE__ */ jsx("option", { value: "", children: "-- Pilih Jenis Wahana --" }),
                    Object.values(wahanaoption || {}).map(
                      (option) => /* @__PURE__ */ jsx(
                        "option",
                        {
                          value: option.id,
                          children: option.jeniswahana
                        },
                        option.id
                      )
                    )
                  ]
                }
              )
            ] }),
            /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx(
              "button",
              {
                type: "submit",
                disabled: processing,
                className: "w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2   transition",
                children: processing ? "Menyimpan..." : "Simpan"
              }
            ) })
          ]
        }
      ),
      /* @__PURE__ */ jsxs("div", { className: "bg-gray-50 p-4 md:p-6   shadow-md border", children: [
        /* @__PURE__ */ jsx("h2", { className: "text-xl font-bold mb-4 text-blue-700", children: "Detail Perhitungan" }),
        /* @__PURE__ */ jsxs("div", { className: "space-y-2 text-gray-700", children: [
          /* @__PURE__ */ jsxs("p", { children: [
            /* @__PURE__ */ jsx("span", { className: "font-semibold", children: "Nama Wahana:" }),
            " ",
            data.nama_wahana || "-"
          ] }),
          /* @__PURE__ */ jsxs("p", { children: [
            /* @__PURE__ */ jsx("span", { className: "font-semibold", children: "Harga per Unit:" }),
            " ",
            "Rp ",
            data.harga.toLocaleString()
          ] }),
          /* @__PURE__ */ jsxs("p", { children: [
            /* @__PURE__ */ jsx("span", { className: "font-semibold", children: "Jumlah:" }),
            " ",
            data.jumlah
          ] }),
          /* @__PURE__ */ jsx("hr", { className: "my-2" }),
          /* @__PURE__ */ jsxs("p", { className: "text-lg font-bold text-blue-600", children: [
            "Total: Rp",
            " ",
            (Number(data.total) || 0).toLocaleString()
          ] })
        ] }),
        /* @__PURE__ */ jsx("div", { className: "mt-8 flex flex-col items-center", children: /* @__PURE__ */ jsx(
          "button",
          {
            onClick: handleShowShiftSummary,
            className: "w-full px-6 py-3 bg-green-600 text-white font-bold hover:bg-green-700 focus:ring-4 focus:ring-green-300",
            children: showShiftSummary ? "Tutup Rincian Shift" : "Akhiri Shift"
          }
        ) })
      ] })
    ] }),
    showShiftSummary && /* @__PURE__ */ jsxs(
      "div",
      {
        ref: shiftSummaryRef,
        className: "mt-8 bg-gray-50 border border-gray-200   p-6 shadow-lg w-full  mx-auto",
        children: [
          /* @__PURE__ */ jsx("h4", { className: "text-lg font-bold mb-4 text-center text-green-700", children: "Rincian Transaksi Shift Hari Ini" }),
          /* @__PURE__ */ jsxs("div", { className: "mb-4", children: [
            /* @__PURE__ */ jsx("strong", { children: "Transaksi Wahana:" }),
            /* @__PURE__ */ jsx("ul", { className: "list-disc ml-6", children: todaySummary.wahana.length > 0 ? todaySummary.wahana.map((t, i) => /* @__PURE__ */ jsxs("li", { children: [
              t.jenis_wahana.jeniswahana || "-",
              " | Jumlah:",
              " ",
              t.jumlah,
              " | Rp ",
              t.harga,
              " | Total: Rp",
              " ",
              (Number(t.harga) * Number(t.jumlah)).toLocaleString(),
              " ",
              "|",
              " ",
              new Date(
                t.created_at
              ).toLocaleTimeString("id-ID")
            ] }, i)) : /* @__PURE__ */ jsx("li", { children: "Tidak ada transaksi wahana hari ini." }) }),
            /* @__PURE__ */ jsxs("div", { className: "mt-2 text-right font-semibold text-blue-700", children: [
              "Total Wahana: Rp",
              " ",
              todaySummary.totalWahana.toLocaleString()
            ] })
          ] }),
          /* @__PURE__ */ jsx("div", { className: "flex justify-center", children: /* @__PURE__ */ jsx(
            "button",
            {
              onClick: handleSaveShiftAndLogout,
              disabled: closingShift,
              className: "px-6 py-3 bg-blue-700 text-white font-bold hover:bg-blue-800 focus:ring-4 focus:ring-blue-300",
              children: closingShift ? "Menyimpan & Logout..." : "Simpan Shift & Logout"
            }
          ) })
        ]
      }
    ),
    /* @__PURE__ */ jsxs("div", { className: "mt-8 bg-white shadow   p-6", children: [
      /* @__PURE__ */ jsx("h3", { className: "text-xl font-bold mb-4", children: "Riwayat Transaksi Wahana" }),
      /* @__PURE__ */ jsxs("div", { className: "flex gap-4 mb-4", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("label", { className: "block text-sm", children: "Dari Tanggal" }),
          /* @__PURE__ */ jsx(
            "input",
            {
              type: "date",
              value: fromDate,
              onChange: (e) => setFromDate(e.target.value),
              className: "border p-2  "
            }
          )
        ] }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("label", { className: "block text-sm", children: "Sampai Tanggal" }),
          /* @__PURE__ */ jsx(
            "input",
            {
              type: "date",
              value: toDate,
              onChange: (e) => setToDate(e.target.value),
              className: "border p-2  "
            }
          )
        ] }),
        /* @__PURE__ */ jsx("div", { className: "flex items-end", children: /* @__PURE__ */ jsx(
          "button",
          {
            onClick: fetchFilteredTransactions,
            className: "bg-green-600 text-white px-4 py-2   hover:bg-green-700",
            children: "Filter"
          }
        ) })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxs("table", { className: "min-w-full text-sm", children: [
        /* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", { className: "bg-gray-100", children: [
          /* @__PURE__ */ jsx("th", { className: "px-2 py-1 text-left", children: "Tanggal" }),
          /* @__PURE__ */ jsx("th", { className: "px-2 py-1 text-left", children: "Nama Wahana" }),
          /* @__PURE__ */ jsx("th", { className: "px-2 py-1 text-right", children: "Jumlah" }),
          /* @__PURE__ */ jsx("th", { className: "px-2 py-1 text-right", children: "Harga" }),
          /* @__PURE__ */ jsx("th", { className: "px-2 py-1 text-right", children: "Total" }),
          /* @__PURE__ */ jsx("th", { className: "px-2 py-1 text-center", children: "Aksi" })
        ] }) }),
        /* @__PURE__ */ jsx("tbody", { children: transactions.length === 0 ? /* @__PURE__ */ jsx("tr", { children: /* @__PURE__ */ jsx(
          "td",
          {
            colSpan: "6",
            className: "text-center py-2 text-gray-400",
            children: "Tidak ada transaksi."
          }
        ) }) : transactions.map((t) => /* @__PURE__ */ jsxs("tr", { className: "border-t", children: [
          /* @__PURE__ */ jsx("td", { className: "px-2 py-1", children: dayjs(t.created_at).format(
            "DD/MM/YYYY"
          ) }),
          /* @__PURE__ */ jsx("td", { className: "px-2 py-1", children: t.jenis_wahana.jeniswahana }),
          /* @__PURE__ */ jsx("td", { className: "px-2 py-1 text-right", children: t.jumlah }),
          /* @__PURE__ */ jsxs("td", { className: "px-2 py-1 text-right", children: [
            "Rp ",
            t.harga.toLocaleString()
          ] }),
          /* @__PURE__ */ jsxs("td", { className: "px-2 py-1 text-right", children: [
            "Rp",
            " ",
            (t.harga * t.jumlah).toLocaleString()
          ] }),
          /* @__PURE__ */ jsx("td", { className: "px-2 py-1 text-center", children: /* @__PURE__ */ jsx(
            "button",
            {
              onClick: () => deleteTransaction(t.id),
              className: "text-red-600 hover:underline",
              children: "Hapus"
            }
          ) })
        ] }, t.id)) })
      ] }) }),
      transactions.length > 0 && /* @__PURE__ */ jsx("div", { className: "flex justify-between mt-4", children: /* @__PURE__ */ jsx(
        "button",
        {
          onClick: deleteAllTransactions,
          className: "text-red-600 hover:underline",
          children: "🗑 Hapus Semua Transaksi"
        }
      ) })
    ] })
  ] }) });
};
export {
  Wahana as default
};

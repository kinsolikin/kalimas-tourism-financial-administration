import { jsx, jsxs } from "react/jsx-runtime";
import { useState, useEffect } from "react";
import { A as Authenticated } from "./AuthenticatedLayout-b7V4Q5Tg.js";
import { router } from "@inertiajs/react";
import Swal from "sweetalert2";
import "dayjs";
import axios from "axios";
import "@headlessui/react";
function Expanse({ expanses = [], users = [], auth }) {
  const [form, setForm] = useState({
    expanse_id: "",
    amount: "",
    description: ""
  });
  const [transactions, setTransactions] = useState([]);
  const fetchTransactions = async () => {
    try {
      const res = await axios.get("/dashboard/expanse/transactions");
      setTransactions(res.data.expanses || []);
    } catch (err) {
      Swal.fire({
        title: "Gagal",
        text: "Gagal mengambil data transaksi",
        icon: "error",
        confirmButtonText: "OK"
      });
    }
  };
  useEffect(() => {
    fetchTransactions();
  }, []);
  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    router.post("/dashboard/expanses/store", form, {
      onSuccess: () => {
        setForm({ expanse_id: "", amount: "", description: "" });
        Swal.fire({
          title: "Berhasil",
          text: "Transaksi pengeluaran berhasil disimpan",
          icon: "success",
          confirmButtonText: "OK"
        });
        fetchTransactions();
      },
      onError: () => {
        Swal.fire({
          title: "Gagal",
          text: "Terjadi kesalahan saat menyimpan transaksi",
          icon: "error",
          confirmButtonText: "OK"
        });
      }
    });
  };
  const handleDelete = async (id) => {
    const result = await Swal.fire({
      title: "Hapus transaksi ini?",
      text: "Tindakan ini tidak bisa dibatalkan!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Ya, hapus!",
      cancelButtonText: "Batal"
    });
    if (result.isConfirmed) {
      try {
        await axios.delete(`/dashboard/expanse/transactions/delete/${id}`);
        Swal.fire("Berhasil!", "Transaksi telah dihapus.", "success");
        fetchTransactions();
      } catch (err) {
        Swal.fire("Gagal!", "Gagal menghapus transaksi.", "error");
      }
    }
  };
  expanses.find((e) => {
    var _a;
    return ((_a = e.name) == null ? void 0 : _a.toLowerCase()) === "mendadak";
  });
  expanses.find(
    (e) => {
      var _a;
      return ((_a = e.name) == null ? void 0 : _a.toLowerCase()) === "operasional";
    }
  );
  return /* @__PURE__ */ jsx(Authenticated, { user: auth.user, children: /* @__PURE__ */ jsxs("div", { className: "max-w-xl mx-auto py-8", children: [
    /* @__PURE__ */ jsxs(
      "form",
      {
        onSubmit: handleSubmit,
        className: "bg-white shadow rounded-lg p-6 space-y-4",
        children: [
          /* @__PURE__ */ jsx("h2", { className: "text-2xl font-bold mb-4", children: "Tambah Transaksi Pengeluaran" }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("label", { className: "block text-sm font-medium mb-1", children: "Jenis Pengeluaran" }),
            /* @__PURE__ */ jsxs("div", { className: "flex gap-4 mt-2", children: [
              /* @__PURE__ */ jsxs("label", { className: "flex items-center cursor-pointer", children: [
                /* @__PURE__ */ jsx(
                  "input",
                  {
                    type: "radio",
                    name: "expanse_id",
                    value: "1",
                    checked: form.expanse_id === "1",
                    onChange: handleChange,
                    className: "form-radio text-blue-600",
                    required: true
                  }
                ),
                /* @__PURE__ */ jsx("span", { className: "ml-2", children: "Operasional" })
              ] }),
              /* @__PURE__ */ jsxs("label", { className: "flex items-center cursor-pointer", children: [
                /* @__PURE__ */ jsx(
                  "input",
                  {
                    type: "radio",
                    name: "expanse_id",
                    value: "2",
                    checked: form.expanse_id === "2",
                    onChange: handleChange,
                    className: "form-radio text-blue-600",
                    required: true
                  }
                ),
                /* @__PURE__ */ jsx("span", { className: "ml-2", children: "Mendadak" })
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("label", { className: "block text-sm font-medium mb-1", children: "Jumlah" }),
            /* @__PURE__ */ jsx(
              "input",
              {
                type: "number",
                name: "amount",
                value: form.amount,
                onChange: handleChange,
                className: "w-full border rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-400",
                placeholder: "0.00",
                min: "0",
                step: "0.01",
                required: true
              }
            )
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("label", { className: "block text-sm font-medium mb-1", children: "Deskripsi" }),
            /* @__PURE__ */ jsx(
              "input",
              {
                type: "text",
                name: "description",
                value: form.description,
                onChange: handleChange,
                className: "w-full border rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-400",
                placeholder: "Opsional"
              }
            )
          ] }),
          /* @__PURE__ */ jsx(
            "button",
            {
              type: "submit",
              className: "w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700 transition font-semibold",
              children: "Simpan"
            }
          )
        ]
      }
    ),
    /* @__PURE__ */ jsxs("div", { className: "mt-6 bg-white shadow rounded-lg p-6", children: [
      /* @__PURE__ */ jsx("h3", { className: "text-xl font-bold mb-4", children: "Riwayat Transaksi" }),
      /* @__PURE__ */ jsx("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxs("table", { className: "min-w-full text-sm", children: [
        /* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", { children: [
          /* @__PURE__ */ jsx("th", { className: "px-2 py-1 text-left", children: "Jenis Pengeluaran" }),
          /* @__PURE__ */ jsx("th", { className: "px-2 py-1 text-right", children: "Jumlah" }),
          /* @__PURE__ */ jsx("th", { className: "px-2 py-1 text-left", children: "Deskripsi" }),
          /* @__PURE__ */ jsx("th", { className: "px-2 py-1" })
        ] }) }),
        /* @__PURE__ */ jsxs("tbody", { children: [
          transactions.length === 0 && /* @__PURE__ */ jsx("tr", { children: /* @__PURE__ */ jsx(
            "td",
            {
              colSpan: 4,
              className: "text-center py-2 text-gray-400",
              children: "Belum ada pengeluaran"
            }
          ) }),
          transactions.map((trx) => /* @__PURE__ */ jsxs("tr", { className: "border-t", children: [
            /* @__PURE__ */ jsx("td", { className: "px-2 py-1", children: trx.expanse_category && trx.expanse_category.name ? trx.expanse_category.name : "" }),
            /* @__PURE__ */ jsx("td", { className: "px-2 py-1 text-right", children: Number(
              trx.amount
            ).toLocaleString("id-ID", {
              style: "currency",
              currency: "IDR"
            }) }),
            /* @__PURE__ */ jsx("td", { className: "px-2 py-1", children: trx.expanse_mendadak ? trx.expanse_mendadak.description : trx.expanse_operasional ? trx.expanse_operasional.description : null }),
            /* @__PURE__ */ jsx("td", { className: "px-2 py-1", children: /* @__PURE__ */ jsx(
              "button",
              {
                onClick: () => handleDelete(trx.id),
                className: "text-red-500 hover:underline",
                children: "Hapus"
              }
            ) })
          ] }, trx.id))
        ] })
      ] }) })
    ] })
  ] }) });
}
export {
  Expanse as default
};

<?php


return [
'midtrans_id' =>env('MIDTRANS_MERCHANT_ID'),
'midtrans_client_id' => env('MIDTRANS_CLIENT_KEY'),
'midtrans_server_key' => env('MIDTRANS_SERVER_KEY'),
    

];
